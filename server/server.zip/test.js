const data = [
    {
        "day": 1,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-01T02:23:13.000Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 2,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-02T03:19:04.000Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 3,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 4,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 5,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 6,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 7,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 8,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 9,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 10,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 11,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 12,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-12T02:13:04.000Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 13,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-13T02:20:41.000Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 14,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-14T02:36:05.000Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 15,
        "present": true,
        "aId": [
            "WFH"
        ],
        "checkIn": "2024-08-15T02:30:17.822Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 16,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-16T02:19:04.000Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 17,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 18,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 19,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 20,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-20T02:25:37.000Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 21,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-21T02:31:39.000Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 22,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-22T03:29:52.000Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 23,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-23T02:19:10.000Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 24,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 25,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 26,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 27,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    },
    {
        "day": 28,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-28T02:09:19.000Z",
        "modifiedCheckIn": "2024-08-28T02:09:19.000Z"
    },
    {
        "day": 29,
        "present": true,
        "aId": [
            "WAO"
        ],
        "checkIn": "2024-08-29T02:21:07.000Z",
        "modifiedCheckIn": "Unspecified"
    },
    {
        "day": 30,
        "present": true,
        "aId": [
            "WFH"
        ],
        "checkIn": "2024-08-30T08:06:57.778Z",
        "modifiedCheckIn": "2024-08-30T08:06:57.778Z"
    },
    {
        "day": 31,
        "present": false,
        "aId": [],
        "checkIn": "",
        "modifiedCheckIn": ""
    }
]
  
  // Convert UTC time to BDT
  function countDelayDays(data){
      const convertUTCToBDT = (utcDate) => {
        const date = new Date(utcDate);
        // BDT is UTC +6 hours
        date.setHours(date.getHours() + 6);
        return date;
      };
      
      // Define the target time in BDT
      const targetHour = 8;
      const targetMinute = 30;
      
      // Calculate the total delay count
      const totalDelayCount = data.reduce((acc, curr) => {
        if (curr.present) {
          const checkInTime = curr.checkIn ? convertUTCToBDT(curr.checkIn) : null;
          const modifiedCheckInTime = curr.modifiedCheckIn && curr.modifiedCheckIn !== 'Unspecified' 
            ? convertUTCToBDT(curr.modifiedCheckIn) 
            : null;
      
          const checkTime = modifiedCheckInTime || checkInTime;
      
          if (checkTime) {
            const hour = checkTime.getUTCHours();
            const minute = checkTime.getUTCMinutes();
      
            // Check if the check time is later than the target time
            if (hour > targetHour || (hour === targetHour && minute > targetMinute)) {
              acc += 1;
            }
          }
        }
        return acc;
      }, 0);

      return totalDelayCount;

  }
  
  console.log(`Total Delay Days: ${countDelayDays(data)}`);
  